# GCam Cinematic Pro X — development build 0.2

Target device: Infinix Hot 10 Play X688B. This is an Android Studio source project, not a prebuilt APK.

## Implemented in this iteration
- CameraX live camera preview.
- Front/back camera switch.
- Photo capture saved to Pictures/GCamCinematicProX.
- Seven still-photo looks: Natural, Warm, Teal, Moody, Vintage, B&W, Sunset. These are applied to the saved JPEG using pixel processing.
- HD-priority video recording saved to Movies/GCamCinematicProX.
- Filter selection and photo/video mode indicators.

## Known limitations (important)
- Filters currently apply to saved still photos only. They are not shown in live preview and are not baked into recorded video yet.
- This is not Google Camera/GCam and does not implement Google's proprietary HDR+ or Night Sight algorithms.
- No computational portrait segmentation, optical stabilization control, manual ISO/shutter/focus, or guaranteed 24/60 fps selection yet.
- CameraX chooses a supported HD recording quality with fallback; exact capabilities depend on the phone firmware/camera provider.
- The project has not been compiled or tested on a physical X688B in this environment. Device testing is required before calling it release-ready.

## Build
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Let Gradle sync complete.
4. Connect the Infinix Hot 10 Play with USB debugging enabled.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Install the generated debug APK and grant camera/microphone permissions.

If Android Studio reports a Gradle or SDK compatibility issue, share the exact error text for correction.
