package com.gcamcinematicprox

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var imageCapture: ImageCapture
    private lateinit var videoCapture: VideoCapture<Recorder>
    private lateinit var cameraExecutor: ExecutorService
    private var recording: Recording? = null
    private var videoMode = false
    private var currentFilter = "Natural"
    private var lens = CameraSelector.DEFAULT_BACK_CAMERA
    private val filters = listOf("Natural", "Warm", "Teal", "Moody", "Vintage", "B&W", "Sunset")
    private val permissionCode = 41
    private lateinit var filterRow: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildUi()
        if (allPermissionsGranted()) startCamera()
        else ActivityCompat.requestPermissions(this,
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), permissionCode)
    }

    private fun buildUi() {
        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        preview = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        base.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))

        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.rgb(8, 10, 14))
        }
        top.addView(TextView(this).apply {
            text = "GCAM CINEMATIC PRO X"
            textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(button("FLIP") {
            lens = if (lens == CameraSelector.DEFAULT_BACK_CAMERA)
                CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            startCamera()
        })
        base.addView(top)

        filterRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(2, 8, 2, 8)
            setBackgroundColor(Color.rgb(8, 10, 14))
        }
        filters.forEach { name ->
            filterRow.addView(TextView(this).apply {
                text = name; textSize = 10f
                setTextColor(if (name == currentFilter) Color.rgb(230,184,92) else Color.WHITE)
                setPadding(7, 12, 7, 12)
                setOnClickListener { selectFilter(name) }
            })
        }
        base.addView(filterRow)

        status = TextView(this).apply {
            text = "PHOTO  •  Filter aktif: Natural"
            textSize = 11f; gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY); setPadding(8, 5, 8, 5)
            setBackgroundColor(Color.rgb(8, 10, 14))
        }
        base.addView(status)

        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER; setPadding(8, 8, 8, 18)
            setBackgroundColor(Color.rgb(8, 10, 14))
        }
        controls.addView(button("PHOTO") { videoMode = false; updateStatus() })
        controls.addView(button("●") { if (videoMode) toggleVideo() else takePhoto() })
        controls.addView(button("VIDEO") { videoMode = true; updateStatus() })
        base.addView(controls)
        setContentView(base)
    }

    private fun button(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 14f; gravity = Gravity.CENTER
        setTextColor(Color.WHITE); setPadding(16, 12, 16, 12)
        setOnClickListener { action() }
    }

    private fun selectFilter(name: String) {
        currentFilter = name
        for (i in 0 until filterRow.childCount) {
            (filterRow.getChildAt(i) as TextView).setTextColor(
                if ((filterRow.getChildAt(i) as TextView).text == name) Color.rgb(230,184,92) else Color.WHITE)
        }
        updateStatus()
    }

    private fun updateStatus() {
        status.text = (if (videoMode) "VIDEO" else "PHOTO") + "  •  Filter: $currentFilter"
    }

    private fun allPermissionsGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionCode && allPermissionsGranted()) startCamera()
        else Toast.makeText(this, "Izin kamera dan mikrofon diperlukan", Toast.LENGTH_LONG).show()
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val p = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build()
            val recorder = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(Quality.HD,
                    FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))).build()
            videoCapture = VideoCapture.withOutput(recorder)
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, lens, p, imageCapture, videoCapture)
            } catch (e: Exception) {
                Toast.makeText(this, "Kamera gagal dimulai: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val temp = File(cacheDir, "capture_${System.currentTimeMillis()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(temp).build()
        imageCapture.takePicture(options, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                try {
                    val original = BitmapFactory.decodeFile(temp.absolutePath)
                        ?: throw IllegalStateException("Gambar tidak dapat dibaca")
                    val filtered = applyFilter(original, currentFilter)
                    val filename = "GCX_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())}.jpg"
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/GCamCinematicProX")
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("Tidak dapat membuat file foto")
                    contentResolver.openOutputStream(uri)?.use { out ->
                        if (!filtered.compress(Bitmap.CompressFormat.JPEG, 94, out))
                            throw IllegalStateException("Gagal menyimpan JPEG")
                    }
                    original.recycle()
                    if (filtered !== original) filtered.recycle()
                    temp.delete()
                    runOnUiThread { Toast.makeText(this@MainActivity,
                        "Foto tersimpan dengan filter $currentFilter", Toast.LENGTH_LONG).show() }
                } catch (e: Exception) {
                    temp.delete()
                    runOnUiThread { Toast.makeText(this@MainActivity,
                        "Pemrosesan foto gagal: ${e.localizedMessage}", Toast.LENGTH_LONG).show() }
                }
            }
            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { Toast.makeText(this@MainActivity,
                    "Gagal mengambil foto: ${exception.message}", Toast.LENGTH_LONG).show() }
            }
        })
    }

    // CPU pixel grading for saved still photos; preview and recorded video remain ungraded in this build.
    private fun applyFilter(src: Bitmap, preset: String): Bitmap {
        if (preset == "Natural") return src
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val row = IntArray(src.width)
        for (y in 0 until src.height) {
            src.getPixels(row, 0, src.width, 0, y, src.width, 1)
            for (x in row.indices) {
                val c = row[x]
                var r = Color.red(c).toFloat()
                var g = Color.green(c).toFloat()
                var b = Color.blue(c).toFloat()
                when (preset) {
                    "Warm" -> { r *= 1.08f; g *= 1.02f; b *= 0.91f }
                    "Teal" -> { r *= 0.92f; g *= 1.02f; b *= 1.08f }
                    "Moody" -> { r *= 0.86f; g *= 0.90f; b *= 0.96f }
                    "Vintage" -> { r = r * 0.90f + 18; g = g * 0.88f + 12; b = b * 0.78f + 8 }
                    "Sunset" -> { r *= 1.12f; g *= 1.01f; b *= 0.84f }
                    "B&W" -> {
                        val gray = 0.299f*r + 0.587f*g + 0.114f*b
                        r = gray; g = gray; b = gray
                    }
                }
                row[x] = Color.rgb(r.toInt().coerceIn(0,255), g.toInt().coerceIn(0,255), b.toInt().coerceIn(0,255))
            }
            out.setPixels(row, 0, src.width, 0, y, src.width, 1)
        }
        return out
    }

    private fun toggleVideo() {
        val active = recording
        if (active != null) { active.stop(); recording = null; return }
        val filename = "GCX_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/GCamCinematicProX")
        }
        val output = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values).build()
        recording = videoCapture.output.prepareRecording(this, output).withAudioEnabled()
            .start(ContextCompat.getMainExecutor(this)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> Toast.makeText(this, "Merekam… tekan ● untuk berhenti", Toast.LENGTH_SHORT).show()
                    is VideoRecordEvent.Finalize -> {
                        recording = null
                        Toast.makeText(this, if (!event.hasError()) "Video HD tersimpan" else "Video gagal: ${event.error}",
                            Toast.LENGTH_LONG).show()
                    }
                }
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
